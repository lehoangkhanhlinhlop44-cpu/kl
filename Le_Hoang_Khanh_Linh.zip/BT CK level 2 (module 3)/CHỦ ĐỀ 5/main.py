import smtplib
import json
import os
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from dotenv import load_dotenv

# 1. Tải các biến môi trường từ file .env (EMAIL_USER, EMAIL_PASS)
load_dotenv()
SENDER_EMAIL = os.getenv("EMAIL_USER")
SENDER_PASSWORD = os.getenv("EMAIL_PASS")

def run_email_automation():
    # 2. Đọc danh sách người nhận từ file JSON
    try:
        with open('CHỦ ĐỀ 5/data.json', 'r', encoding='utf-8') as f:
            recipients = json.load(f)
    except FileNotFoundError:
        print("Lỗi: Không tìm thấy file data.json")
        return

    # 3. Đọc mẫu nội dung từ file HTML
    try:
        with open('CHỦ ĐỀ 5/template.html', 'r', encoding='utf-8') as f:
            html_template = f.read()
    except FileNotFoundError:
        print("Lỗi: Không tìm thấy file template.html")
        return

    # 4. Thiết lập kết nối SMTP (Sử dụng Gmail)
    try:
        print("Đang kết nối đến server...")
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()  # Bảo mật kết nối
        server.login(SENDER_EMAIL, SENDER_PASSWORD)
        
        for person in recipients:
            name = person['name']
            email = person['email']
            
            # Thay thế biến {{name}} trong file HTML bằng tên thật
            custom_content = html_template.replace("{{name}}", name)
            
            # Tạo đối tượng Email
            msg = MIMEMultipart()
            msg['From'] = SENDER_EMAIL
            msg['To'] = email
            msg['Subject'] = f"THƯ MỜI SỰ KIỆN - Gửi {name}"
            
            msg.attach(MIMEText(custom_content, 'html'))
            
            # Gửi mail
            server.send_message(msg)
            print(f"✅ Đã gửi thành công cho: {name} ({email})")
            
        server.quit()
        print("--- HOÀN THÀNH TẤT CẢ ---")

    except Exception as e:
        print(f"❌ Có lỗi xảy ra: {e}")

if __name__ == "__main__":
    run_email_automation()