import os

# Nội dung cho từng file
files_content = {
    # 1. File HTML Template (Giao diện thư mời)
    "template.html": """<!doctype html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>

body {
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  margin:0; 
  padding:0;
  background: linear-gradient(135deg, #fce7f3 0%, #fbcfe8 50%, #fce7f3 100%);
  background-size: 400% 400%;
  animation: gradientMove 15s ease infinite;
  min-height: 100vh;
}

@keyframes gradientMove {
  0% { background-position: 0% 50%; }
  50% { background-position: 100% 50%; }
  100% { background-position: 0% 50%; }
}

.container {
  width:100%; 
  max-width:720px;
  margin:32px auto;
  background: linear-gradient(145deg, #ffffff 0%, #f8f9ff 100%);
  border-radius:16px;
  overflow:hidden;
  box-shadow: 0 20px 60px rgba(0,0,0,0.15), 0 0 0 1px rgba(255,255,255,0.5);
}

.header {
  background: linear-gradient(135deg, #4158D0 0%, #C850C0 100%);
  color:#fff;
  padding:24px 28px;
  position:relative;
  display:flex;
  justify-content:space-between;
  align-items:center;
  box-shadow: 0 4px 15px rgba(65, 88, 208, 0.3);
}

.logo { 
  font-weight:700; 
  font-size:19px; 
  text-shadow: 0 2px 8px rgba(0,0,0,0.2);
  letter-spacing: 0.3px;
}

/* Ảnh thẻ học sinh */
.student-photo {
  width:80px; 
  height:80px;
  border-radius:12px;
  object-fit:cover;
  border:3px solid rgba(255,255,255,0.9);
  box-shadow: 0 4px 12px rgba(0,0,0,0.2);
  transition: transform 0.3s ease;
}

.student-photo:hover {
  transform: scale(1.05);
}

.content { 
  padding:28px 28px; 
}

.greeting { 
  font-size:17px; 
  margin-bottom:16px;
  color: #2d3748;
}

.summary {
  background: linear-gradient(135deg, #e0e7ff 0%, #ede9fe 100%);
  border:1px solid #c7d2fe;
  padding:16px;
  border-radius:10px;
  margin-bottom:20px;
  box-shadow: 0 2px 8px rgba(99, 102, 241, 0.08);
}

.info {
  margin: 8px 0;
  color: #374151;
  font-size: 14.5px;
}

table { 
  width:100%; 
  border-collapse:collapse; 
  margin-bottom:18px;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 2px 10px rgba(0,0,0,0.05);
}

th, td {
  padding:12px 14px;
  text-align:left;
  border-bottom:1px solid #e5e7eb;
  font-size:14.5px;
}

th { 
  background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
  color:#ffffff; 
  font-weight:600;
  text-transform: uppercase;
  font-size: 13px;
  letter-spacing: 0.5px;
}

tbody tr {
  transition: background-color 0.2s ease;
}

tbody tr:hover {
  background-color: #f9fafb;
}

.grade-good { 
  color:#059669; 
  font-weight:700;
  background: #d1fae5;
  padding: 4px 10px;
  border-radius: 6px;
  display: inline-block;
}

.grade-warning { 
  color:#d97706; 
  font-weight:700;
  background: #fef3c7;
  padding: 4px 10px;
  border-radius: 6px;
  display: inline-block;
}

.grade-bad { 
  color:#dc2626; 
  font-weight:700;
  background: #fee2e2;
  padding: 4px 10px;
  border-radius: 6px;
  display: inline-block;
}

.gpa-display {
  font-weight:700;
  color: #4f46e5;
  font-size: 18px;
}

.advice-box {
  background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
  border:2px solid #fbbf24;
  padding:16px;
  border-radius:10px;
  margin-top:16px;
  box-shadow: 0 2px 8px rgba(251, 191, 36, 0.15);
}

.footer {
  font-size:13.5px; 
  color:#6b7280;
  padding:20px 28px;
  background: linear-gradient(135deg, #f9fafb 0%, #f3f4f6 100%);
  border-top:1px solid #e5e7eb;
}

.footer a {
  color:#6366f1;
  text-decoration:none;
  font-weight: 500;
  transition: color 0.2s ease;
}

.footer a:hover {
  color:#4f46e5;
  text-decoration: underline;
}

.btn {
  display:inline-block;
  background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
  color:#fff;
  padding:12px 24px;
  border-radius:8px;
  text-decoration:none;
  font-weight:600;
  margin-top:12px;
  box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);
  transition: all 0.3s ease;
  font-size: 14.5px;
}

.btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(99, 102, 241, 0.4);
}

.btn-secondary {
  background: linear-gradient(135deg, #ec4899 0%, #f472b6 100%);
  box-shadow: 0 4px 12px rgba(236, 72, 153, 0.3);
}

.btn-secondary:hover {
  box-shadow: 0 6px 20px rgba(236, 72, 153, 0.4);
}

@media (max-width:480px){
  .container { margin:16px; }
  th, td { padding:10px; font-size: 13px; }
  .header { flex-direction:column; gap:12px; padding: 20px; }
  .student-photo { width:70px; height:70px; }
  .content { padding: 20px; }
}
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <div class="logo">THCS Lê Văn Tám Lớp 8/12 — Báo cáo điểm</div>
    <img class="student-photo" src="gen-h-ảnh.jpg" alt="Ảnh học sinh">
  </div>
  
  <div class="content">
    <p class="greeting">Xin chào <strong>HS Lê Hoàng Khánh Linh</strong>,</p>
    
    <div class="summary">
      <p class="info"><strong>Lớp:</strong> 8/12 &nbsp; | &nbsp; <strong>Học kỳ:</strong> 2</p>
      <p class="info"><strong>Người báo cáo:</strong> Thầy Ngô Văn Hưng &nbsp; | &nbsp; <strong>Ngày:</strong> 18/1/2026</p>
    </div>
    
    <p style="margin:0 0 12px 0; font-weight:600; color:#374151;">Bảng điểm chi tiết:</p>
    
    <table role="table">
      <thead>
        <tr>
          <th>Môn học</th>
          <th>Điểm giữa kỳ</th>
          <th>Điểm cuối kỳ</th>
          <th>Điểm TB</th>
          <th>Nhận xét</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>Toán học</td>
          <td>8.5</td>
          <td>9.0</td>
          <td><span class="grade-good">8.75</span></td>
          <td>Tiến bộ tốt</td>
        </tr>
        <tr>
          <td>Ngữ văn</td>
          <td>7.0</td>
          <td>7.5</td>
          <td><span class="grade-warning">7.25</span></td>
          <td>Cần cải thiện</td>
        </tr>
        <tr>
          <td>Tiếng Anh</td>
          <td>9.0</td>
          <td>9.5</td>
          <td><span class="grade-good">9.25</span></td>
          <td>Xuất sắc</td>
        </tr>
        <tr>
          <td>Vật lý</td>
          <td>6.5</td>
          <td>7.0</td>
          <td><span class="grade-warning">6.75</span></td>
          <td>Khá</td>
        </tr>
        <tr>
          <td>Hóa học</td>
          <td>8.0</td>
          <td>8.5</td>
          <td><span class="grade-good">8.25</span></td>
          <td>Tốt</td>
        </tr>
      </tbody>
    </table>
    
    <p><strong>Điểm trung bình chung:</strong> <span class="gpa-display">8.05</span></p>
    
    <div class="advice-box">
      <p style="margin:0; font-weight:600; color:#92400e;">Gợi ý / Khuyến nghị:</p>
      <p style="margin:8px 0 0 0; color:#78350f;">Em đang có kết quả học tập tốt. Hãy tiếp tục duy trì và cải thiện thêm ở môn Ngữ văn để đạt kết quả cao hơn.</p>
    </div>
    
    <p style="margin-top:18px; color:#4b5563;">Nếu bạn có câu hỏi hoặc cần thảo luận chi tiết, vui lòng liên hệ giáo viên chủ nhiệm.</p>
    
    <div style="display: flex; gap: 12px; flex-wrap: wrap;">
      <a class="btn" href="#details">Xem chi tiết tại hệ thống</a>
      <a class="btn btn-secondary" href="#contact-teacher">Trao đổi với giáo viên</a>
    </div>
  </div>
  
  <div class="footer">
    <div>Trường: <strong>THCS Lê Văn Tám</strong></div>
    <div style="margin-top:8px;">
      <strong>Địa chỉ:</strong>
      <a href="https://maps.app.goo.gl/Qp6fSMvSbNjQAK1D7" target="_blank">
        107F Chu Văn An, Phường 26, Bình Thạnh, Thành phố Hồ Chí Minh
      </a>
    </div>
    <div style="margin-top:8px;">
      Đây là email tự động. Vui lòng không trả lời trực tiếp vào email này.
    </div>
  </div>
</div>
</body>
</html>  margin:0; 
""",

    # 2. File JSON (Cơ sở dữ liệu cá nhân)
    "data.json": """[
    {"name": "Ngô Văn Hưng", "email": "hngo0131@gmail.com"}

]""",

    # 3. File .env (Bảo mật dữ liệu cá nhân)
    ".env": "EMAIL_USER=lehoangkhanhlinhlop44@gmail.com\nEMAIL_PASS=ssib qnwk inyc uwou",

    # 4. File main.py (Code gửi mail tự động)
    "main.py": """import smtplib
import json
import os
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from dotenv import load_dotenv

# 1. Tải các biến môi trường từ file .env (EMAIL_USER, EMAIL_PASS)
load_dotenv()
SENDER_EMAIL = os.getenv("EMAIL_USER")
SENDER_PASSWORD = os.getenv("EMAIL_PASS")

def run_email_automation():
    # 2. Đọc danh sách người nhận từ file JSON
    try:
        with open('data.json', 'r', encoding='utf-8') as f:
            recipients = json.load(f)
    except FileNotFoundError:
        print("Lỗi: Không tìm thấy file data.json")
        return

    # 3. Đọc mẫu nội dung từ file HTML
    try:
        with open('template.html', 'r', encoding='utf-8') as f:
            html_template = f.read()
    except FileNotFoundError:
        print("Lỗi: Không tìm thấy file template.html")
        return

    # 4. Thiết lập kết nối SMTP (Sử dụng Gmail)
    try:
        print("Đang kết nối đến server...")
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()  # Bảo mật kết nối
        server.login(SENDER_EMAIL, SENDER_PASSWORD)
        
        for person in recipients:
            name = person['name']
            email = person['email']
            
            # Thay thế biến {{name}} trong file HTML bằng tên thật
            custom_content = html_template.replace("{{name}}", name)
            
            # Tạo đối tượng Email
            msg = MIMEMultipart()
            msg['From'] = SENDER_EMAIL
            msg['To'] = email
            msg['Subject'] = f"THƯ MỜI SỰ KIỆN - Gửi {name}"
            
            msg.attach(MIMEText(custom_content, 'html'))
            
            # Gửi mail
            server.send_message(msg)
            print(f"✅ Đã gửi thành công cho: {name} ({email})")
            
        server.quit()
        print("\n--- HOÀN THÀNH TẤT CẢ ---")

    except Exception as e:
        print(f"❌ Có lỗi xảy ra: {e}")

if __name__ == "__main__":
    run_email_automation()"""
}

# Tiến hành tạo các file
for filename, content in files_content.items():
    with open(filename, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"Đã tạo file thành công: {filename}")

print("\n--- HOÀN TẤT: Tất cả các file đã sẵn sàng! ---")