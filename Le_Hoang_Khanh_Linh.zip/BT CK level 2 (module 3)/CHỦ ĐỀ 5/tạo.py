import os

# Nội dung cho từng file
files_content = {
    # 1. File HTML Template (Giao diện thư mời)
    "template.html": """<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Xác nhận đơn hàng</title>
</head>
<body style="
    margin: 0;
    padding: 40px 20px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
    background: linear-gradient(135deg, #fff8e1 0%, #ffefc2 100%);
    color: #2c3e50;
">

    
    <div style="max-width: 650px; margin: 0 auto; border-radius: 16px; overflow: hidden; background-color: #ffffff; box-shadow: 0 10px 40px rgba(0,0,0,0.08);">
        
        <!-- Tiêu đề trang và hiệu ứng chỉnh màu -->
    <!-- Tiêu đề-->
<div style="
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    padding: 50px 30px 45px;
    text-align: center;
">

    <!-- Logo -->
    <img src="logo.png"
         alt="Kingcontent"
         style="
            width: 260px;
            max-width: 85%;
            display: block;
            margin: 0 auto 16px auto;
         ">

    <!-- Mã đơn hàng -->
    <div style="
        display: inline-block;
        background-color: rgba(255,255,255,0.25);
        padding: 10px 26px;
        border-radius: 999px;
    ">
        <span style="
            color: #ffffff;
            font-size: 14px;
            font-weight: 600;
            letter-spacing: 0.8px;
        ">
            Đơn hàng #KCT231234
        </span>
    </div>

</div>


        <!-- Nội dung chính -->
        <div style="padding: 40px 30px; text-align: center;">
<div style="
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 16px;
    margin-bottom: 18px;
">

    <h2 style="
        margin: 0;
        font-size: 28px;
        font-weight: 700;
        color: #2c3e50;
    ">
        Đặt hàng thành công!
    </h2>

    <div style="
        width: 56px;
        height: 56px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
    ">
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="20 6 9 17 4 12"></polyline>
        </svg>
    </div>

</div>

            <p style="color: #5a6c7d; line-height: 1.7; margin: 0 0 10px 0; font-size: 15px;">
                Xin chào <strong style="color: #667eea;">Nam</strong>, đơn hàng của bạn đã sẵn sàng để vận chuyển. Chúng tôi sẽ thông báo ngay khi đơn hàng được giao đến bạn.
            </p>
            <p style="font-size: 13px; color: #95a5a6; margin-bottom: 25px;">— Kingcontent team —</p>
            <a href="#" style="background: linear-gradient(135deg, #ffd89b 0%, #f7d081 100%); color: #2c3e50; padding: 14px 32px; text-decoration: none; border-radius: 25px; font-weight: 700; display: inline-block; box-shadow: 0 4px 15px rgba(247, 208, 129, 0.4); transition: transform 0.2s; font-size: 14px; letter-spacing: 0.3px;">
                Xem chi tiết đơn hàng →
            </a>
        </div>

        <!-- Tóm tắt đơn hàng -->
        <div style="margin: 0 30px 30px 30px; border-radius: 12px; overflow: hidden; border: 1px solid #e8ecf1;">
            <div style="background: linear-gradient(to right, #f8f9fa, #ffffff); padding: 18px 20px; border-bottom: 2px solid #667eea; font-weight: 700; font-size: 16px; color: #2c3e50;">
                📦 Tóm tắt đơn hàng
            </div>
            
            <!-- Sản phẩm -->
            <div style="padding: 20px; border-bottom: 1px solid #f0f3f7;">
                <table style="width: 100%; border-collapse: collapse;">
                    <tr>
                        <td style="width: 80px; padding-right: 15px;">
                            <div style="background: linear-gradient(135deg, #f5f7fa 0%, #e8edf2 100%); padding: 10px; border-radius: 10px;">
                                <img src="tv-box-scaled.png" alt="Box" style="width: 60px; border-radius: 6px; display: block;">
                            </div>
                        </td>
                        <td style="font-size: 15px; color: #2c3e50; font-weight: 600; vertical-align: middle;">
                            Box truyền hình
                        </td>
                        <td style="text-align: right; font-weight: 700; font-size: 16px; color: #667eea; vertical-align: middle;">
                            500.000₫
                        </td>
                    </tr>
                </table>
            </div>

            <!-- Tiêu đề tóm tắt thanh toán -->
            <div style="background: linear-gradient(to right, #f8f9fa, #ffffff); padding: 15px 20px; border-top: 1px solid #e8ecf1; border-bottom: 1px solid #e8ecf1; font-weight: 700; color: #2c3e50; font-size: 15px;">
                💳 Chi phí thanh toán
            </div>

            <!-- Chi tiết thanh toán -->
            <div style="padding: 20px;">
                <table style="width: 100%; border-collapse: collapse; font-size: 14px;">
                    <tr>
                        <td style="padding: 8px 0; color: #5a6c7d;">Giá sản phẩm</td>
                        <td style="text-align: right; font-weight: 600; color: #2c3e50;">500.000₫</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px 0; color: #5a6c7d;">Thuế VAT</td>
                        <td style="text-align: right; font-weight: 600; color: #2c3e50;">10.000₫</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px 0; color: #5a6c7d;">Phí vận chuyển</td>
                        <td style="text-align: right; font-weight: 600; color: #2c3e50;">20.000₫</td>
                    </tr>
                    <tr>
                        <td colspan="2" style="padding: 12px 0;">
                            <div style="height: 1px; background: linear-gradient(to right, transparent, #e8ecf1, transparent);"></div>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding: 8px 0; color: #27ae60; font-weight: 600;">🎁 Khuyến mãi</td>
                        <td style="text-align: right; font-weight: 700; color: #27ae60;">-200.000₫</td>
                    </tr>
                    <tr>
                        <td colspan="2" style="padding: 15px 0 0 0;">
                            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 8px; padding: 15px; display: flex; justify-content: space-between; align-items: center;">
                                <span style="color: #fff; font-size: 16px; font-weight: 700;">Tổng thanh toán</span>
                                <span style="color: #ffd89b; font-size: 22px; font-weight: 800;">270.000₫</span>
                            </div>
                        </td>
                    </tr>
                </table>
            </div>
        </div>

        <!-- Thông tin khách hàng -->
        <div style="margin: 0 30px 40px 30px;">
            <h3 style="font-size: 16px; font-weight: 700; color: #2c3e50; margin-bottom: 20px; padding-bottom: 10px; border-bottom: 3px solid #667eea; display: inline-block;">
                👤 THÔNG TIN KHÁCH HÀNG
            </h3>
            
            <div style="display: flex; gap: 20px; margin-bottom: 25px;">
                <div style="flex: 1; background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%); padding: 20px; border-radius: 10px; border-left: 4px solid #667eea;">
                    <div style="font-weight: 700; font-size: 14px; color: #2c3e50; margin-bottom: 12px;">📍 Địa chỉ giao hàng</div>
                    <div style="font-size: 13px; line-height: 1.8; color: #5a6c7d;">
                        <strong style="color: #2c3e50;">Nam</strong><br>
                        100 đường Nguyễn Huệ<br>
                        Tp. Kontum, Kontum<br>
                        Việt Nam
                    </div>
                </div>
                <div style="flex: 1; background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%); padding: 20px; border-radius: 10px; border-left: 4px solid #764ba2;">
                    <div style="font-weight: 700; font-size: 14px; color: #2c3e50; margin-bottom: 12px;">💰 Địa chỉ thanh toán</div>
                    <div style="font-size: 13px; line-height: 1.8; color: #5a6c7d;">
                        <strong style="color: #2c3e50;">Nam</strong><br>
                        100 đường Nguyễn Huệ<br>
                        Tp. Kontum, Kontum<br>
                        Việt Nam
                    </div>
                </div>
            </div>
            
            <div style="background: linear-gradient(135deg, #ffd89b 0%, #f7d081 100%); padding: 18px 20px; border-radius: 10px;">
                <div style="font-weight: 700; font-size: 14px; color: #2c3e50; margin-bottom: 5px;">🚚 Phương thức vận chuyển</div>
                <div style="font-size: 13px; color: #5a4a1f; font-weight: 600;">Chuyển phát nhanh Express</div>
            </div>
        </div>

        <!-- Chân trang -->
        <div style="background: linear-gradient(to right, #f8f9fa, #ffffff); padding: 25px 30px; text-align: center; border-top: 1px solid #e8ecf1;">
            <p style="margin: 0 0 10px 0; font-size: 13px; color: #7f8c8d;">
                Cảm ơn bạn đã tin tưởng sử dụng dịch vụ của Kingcontent!
            </p>
            <p style="margin: 0; font-size: 12px; color: #95a5a6;">
                © 2024 Kingcontent. All rights reserved.
            </p>
        </div>
    </div>
</body>
</html>""",

    # 2. File JSON (Cơ sở dữ liệu cá nhân)
    "data.json": """[
    {"name": "Ngô Văn Hưng", "email": "hngo0131@gmail.com"}

]""",

    # 3. File .env (Bảo mật dữ liệu cá nhân)
    ".env": "EMAIL_USER=lehoangkhanhlinhlop44@gmail.com\nEMAIL_PASS=ssib qnwk inyc uwou",

    # 4. File main.py (Code gửi mail tự động)
    "main.py": """import smtplib
import json
import os
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from dotenv import load_dotenv

# 1. Tải các biến môi trường từ file .env (EMAIL_USER, EMAIL_PASS)
load_dotenv()
SENDER_EMAIL = os.getenv("EMAIL_USER")
SENDER_PASSWORD = os.getenv("EMAIL_PASS")

def run_email_automation():
    # 2. Đọc danh sách người nhận từ file JSON
    try:
        with open('data.json', 'r', encoding='utf-8') as f:
            recipients = json.load(f)
    except FileNotFoundError:
        print("Lỗi: Không tìm thấy file data.json")
        return

    # 3. Đọc mẫu nội dung từ file HTML
    try:
        with open('template.html', 'r', encoding='utf-8') as f:
            html_template = f.read()
    except FileNotFoundError:
        print("Lỗi: Không tìm thấy file template.html")
        return

    # 4. Thiết lập kết nối SMTP (Sử dụng Gmail)
    try:
        print("Đang kết nối đến server...")
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()  # Bảo mật kết nối
        server.login(SENDER_EMAIL, SENDER_PASSWORD)
        
        for person in recipients:
            name = person['name']
            email = person['email']
            
            # Thay thế biến {{name}} trong file HTML bằng tên thật
            custom_content = html_template.replace("{{name}}", name)
            
            # Tạo đối tượng Email
            msg = MIMEMultipart()
            msg['From'] = SENDER_EMAIL
            msg['To'] = email
            msg['Subject'] = f"THƯ MỜI SỰ KIỆN - Gửi {name}"
            
            msg.attach(MIMEText(custom_content, 'html'))
            
            # Gửi mail
            server.send_message(msg)
            print(f"✅ Đã gửi thành công cho: {name} ({email})")
            
        server.quit()
        print("\n--- HOÀN THÀNH TẤT CẢ ---")

    except Exception as e:
        print(f"❌ Có lỗi xảy ra: {e}")

if __name__ == "__main__":
    run_email_automation()"""
}

# Tiến hành tạo các file
for filename, content in files_content.items():
    with open(filename, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"Đã tạo file thành công: {filename}")

print("\n--- HOÀN TẤT: Tất cả các file đã sẵn sàng! ---")