import os

# Nội dung cho từng file
files_content = {
    # 1. File HTML Template (Giao diện thư mời)
    "template.html": """<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Thư mời tham gia sự kiện</title>
</head>
<body style="margin:0;padding:0;background:linear-gradient(135deg, #b3c5e8 0%, #c5d9f5 100%);font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="padding:40px 20px;">
    <tr>
      <td align="center">
        <table width="650" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 20px 60px rgba(0,0,0,0.3);">
          
          <!-- thanh trang trí phía trên -->
          <tr>
            <td style="background:linear-gradient(90deg, #d4af37 0%, #f4d03f 50%, #d4af37 100%);height:6px;"></td>
          </tr>

          <!-- Tiêu đề có hiệu ứng chuyển màu -->
          <tr>
            <td style="background:linear-gradient(135deg, #1a237e 0%, #283593 100%);padding:35px 40px;">
              <table width="100%">
                <tr>
                  <td align="left" style="font-size:28px;font-weight:700;color:#ffffff;letter-spacing:1px;">
                    CCBOOK
                    <div style="font-size:11px;color:#ffcc00;font-weight:600;margin-top:5px;letter-spacing:2px;">CCGROUP EDUCATION</div>
                  </td>
                  <td align="right">
                    <div style="background:rgba(255,255,255,0.15);backdrop-filter:blur(10px);border-radius:8px;padding:10px 18px;display:inline-block;border:1px solid rgba(255,255,255,0.2);">
                      <div style="color:#ffcc00;font-size:14px;font-weight:700;margin-bottom:3px;">CC THẦN TỐC</div>
                      <div style="color:#ffffff;font-size:12px;font-weight:600;">LUYỆN ĐỀ 2026</div>
                    </div>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Yếu tố trang trí -->
          <tr>
            <td style="background:linear-gradient(to bottom, #283593, #ffffff);height:40px;position:relative;">
              <div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);background:#ffffff;width:80px;height:80px;border-radius:50%;border:4px solid #d4af37;box-shadow:0 4px 20px rgba(212,175,55,0.3);"></div>
            </td>
          </tr>

          <!-- Phần tiêu đề -->
          <tr>
            <td align="center" style="padding:50px 40px 30px 40px;">
              <div style="display:inline-block;position:relative;">
                <div style="font-size:36px;font-weight:800;color:#1a237e;letter-spacing:2px;text-transform:uppercase;line-height:1.3;">
                  Thư mời<br>
                  <span style="background:linear-gradient(135deg, #d4af37 0%, #f4d03f 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;">Tham gia sự kiện</span>
                </div>
                <div style="position:absolute;bottom:-15px;left:0;right:0;height:3px;background:linear-gradient(90deg, transparent, #d4af37, transparent);"></div>
              </div>
            </td>
          </tr>

          <!-- Nội dung -->
          <tr>
            <td align="center" style="padding:30px 60px;font-size:16px;line-height:1.8;color:#424242;">
              <div style="background:linear-gradient(135deg, #fff8e1 0%, #fffbf0 100%);padding:30px;border-radius:12px;border-left:4px solid #d4af37;border:2px solid #f4d03f;">
                Trân trọng kính mời <strong style="color:#1a237e;">Quý phụ huynh</strong> và <strong style="color:#1a237e;">các em học sinh</strong> đến tham dự<br>
                <div style="margin:15px 0;font-size:15px;color:#616161;">Lễ ra mắt bộ sách</div>
                <div style="font-size:20px;font-weight:700;color:#1a237e;line-height:1.5;margin-top:10px;">
                  "CC Thần tốc luyện đề<br>chinh phục kì thi THPT QG 2026"
                </div>
              </div>
            </td>
          </tr>

          <!-- Thời gian & Ngày -->
          <tr>
            <td align="center" style="padding:35px 40px;">
              <div style="display:inline-block;background:linear-gradient(135deg, #1a237e 0%, #283593 100%);padding:20px 50px;border-radius:50px;box-shadow:0 10px 30px rgba(26,35,126,0.3);position:relative;">
                <div style="position:absolute;top:-3px;left:-3px;right:-3px;bottom:-3px;background:linear-gradient(135deg, #d4af37, #f4d03f);border-radius:50px;z-index:-1;"></div>
                <table cellpadding="0" cellspacing="0">
                  <tr>
<td style="padding:0 20px;border-right:2px solid rgba(255,255,255,0.2); text-align:center;">
  <div style="color:#ffcc00;font-size:13px;font-weight:600;margin-bottom:5px;">
    THỜI GIAN
  </div>
  <div style="color:#ffffff;font-size:24px;font-weight:800;">
    9:00
  </div>
</td>

                    <td style="padding:0 20px;text-align:center;">
  <div style="color:#ffcc00;font-size:13px;font-weight:600;margin-bottom:5px;">
    NGÀY
  </div>
  <div style="color:#ffffff;font-size:24px;font-weight:800;">
    10.01.2026
  </div>
</td>

                  </tr>
                </table>
              </div>
            </td>
          </tr>

          <!-- Vị trí -->
          <tr>
            <td align="center" style="padding:20px 60px 40px 60px;">
              <div style="background:linear-gradient(135deg, #fff8e1 0%, #ffffff 100%);border:2px solid #d4af37;border-radius:12px;padding:25px;position:relative;">
                <div style="position:absolute;top:-15px;left:50%;transform:translateX(-50%);background:#ffffff;padding:5px 20px;border:2px solid #d4af37;border-radius:20px;">
                  <span style="color:#d4af37;font-weight:700;font-size:13px;">📍 ĐỊA ĐIỂM</span>
                </div>
                <div style="font-size:17px;font-weight:700;color:#1a237e;margin-top:10px;margin-bottom:8px;">
                  Hội trường, Tầng 1, Cung trí thức
                </div>
                <div style="font-size:14px;color:#616161;line-height:1.6;">
                  Số 1 Tôn Thất Thuyết – Dịch Vọng – Cầu Giấy – Hà Nội
                </div>
              </div>
            </td>
          </tr>

          <!-- Vách ngăn trang trí -->
          <tr>
            <td style="padding:0 40px;">
              <div style="height:1px;background:linear-gradient(90deg, transparent, #d4af37, transparent);"></div>
            </td>
          </tr>

          <!-- Chân trang -->
          <tr>
            <td style="padding:30px 40px;background:linear-gradient(to bottom, #ffffff, #f8f9fa);">
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td align="left" style="font-size:12px;line-height:1.7;color:#616161;vertical-align:top;padding-right:20px;">
                    <div style="font-weight:700;color:#1a237e;margin-bottom:8px;font-size:13px;">Công ty Cổ phần Ccgroup Toàn cầu</div>
                    <div>📍 Số 10 Dương Quảng Hàm – Quan Hoa<br>Cầu Giấy – Hà Nội</div>
                  </td>
                  <td align="right" style="font-size:12px;line-height:1.7;vertical-align:top;">
<div style="
    background:linear-gradient(135deg, #1a237e 0%, #283593 100%);
    color:#ffffff;
    padding:18px 24px;
    border-radius:10px;
    display:inline-block;
    text-align:center;
">
  <div style="font-weight:700;margin-bottom:6px;color:#ffcc00;">
    ✓ Xác nhận tham gia
  </div>
  <div style="font-size:14px;font-weight:600;">
    Ms. Linh – 0703 585 384
  </div>
</div>

                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Thanh trang trí phía dưới -->
          <tr>
            <td style="background:linear-gradient(90deg, #d4af37 0%, #f4d03f 50%, #d4af37 100%);height:6px;"></td>
          </tr>

        </table>

        <!-- Note cuối -->
        <tr>
          <td align="center" style="padding-top:20px;">
            <div style="color:#ffffff;font-size:11px;opacity:0.8;">
              © 2026 CCGroup. Rất hân hạnh được đón tiếp Quý khách.
            </div>
          </td>
        </tr>

      </td>
    </tr>
  </table>
</body>
</html>""",

    # 2. File JSON (Cơ sở dữ liệu cá nhân)
    "data.json": """[
    {"name": "Lê Hoàng Khánh Linh", "email": "lehoangkhanhlinhlop44@gmail.com"}

]""",

    # 3. File .env (Bảo mật dữ liệu cá nhân)
    ".env": "EMAIL_USER=lehoangkhanhlinhlop44@gmail.com\nEMAIL_PASS=ssib qnwk inyc uwou",

    # 4. File main.py (Code gửi mail tự động)
    "main.py": """import smtplib
import json
import os
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from dotenv import load_dotenv

# 1. Tải các biến môi trường từ file .env (EMAIL_USER, EMAIL_PASS)
load_dotenv()
SENDER_EMAIL = os.getenv("EMAIL_USER")
SENDER_PASSWORD = os.getenv("EMAIL_PASS")

def run_email_automation():
    # 2. Đọc danh sách người nhận từ file JSON
    try:
        with open('data.json', 'r', encoding='utf-8') as f:
            recipients = json.load(f)
    except FileNotFoundError:
        print("Lỗi: Không tìm thấy file data.json")
        return

    # 3. Đọc mẫu nội dung từ file HTML
    try:
        with open('template.html', 'r', encoding='utf-8') as f:
            html_template = f.read()
    except FileNotFoundError:
        print("Lỗi: Không tìm thấy file template.html")
        return

    # 4. Thiết lập kết nối SMTP (Sử dụng Gmail)
    try:
        print("Đang kết nối đến server...")
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()  # Bảo mật kết nối
        server.login(SENDER_EMAIL, SENDER_PASSWORD)
        
        for person in recipients:
            name = person['name']
            email = person['email']
            
            # Thay thế biến {{name}} trong file HTML bằng tên thật
            custom_content = html_template.replace("{{name}}", name)
            
            # Tạo đối tượng Email
            msg = MIMEMultipart()
            msg['From'] = SENDER_EMAIL
            msg['To'] = email
            msg['Subject'] = f"THƯ MỜI SỰ KIỆN - Gửi {name}"
            
            msg.attach(MIMEText(custom_content, 'html'))
            
            # Gửi mail
            server.send_message(msg)
            print(f"✅ Đã gửi thành công cho: {name} ({email})")
            
        server.quit()
        print("\n--- HOÀN THÀNH TẤT CẢ ---")

    except Exception as e:
        print(f"❌ Có lỗi xảy ra: {e}")

if __name__ == "__main__":
    run_email_automation()"""
}

# Tiến hành tạo các file
for filename, content in files_content.items():
    with open(filename, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"Đã tạo file thành công: {filename}")

print("\n--- HOÀN TẤT: Tất cả các file đã sẵn sàng! ---")